<?php

namespace PhpOffice\PhpSpreadsheet\Calculation\Internal;

class MakeMatrix
{
    /**
     * @param mixed[] $args
     *
     * @return mixed[]
     */
    public static function make(...$args): array
    {
        return $args;
    }
}
